// JavaScript to change background color
document.getElementById('changeColorBtn').addEventListener('click', function() {
    document.body.style.backgroundColor = '#e74c3c';  // Change background color to red
});
